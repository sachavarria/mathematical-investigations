"""Verify the stronger lattice-face normal form and the linear algorithm."""
from collections import Counter, defaultdict
from itertools import combinations, permutations, product
from fractions import Fraction
from math import prod
import json
import random
from geometry import barycentric
from linear import graph_coefficient
from verify import sign

rng = random.Random(112526)
counts = Counter()

def analyze(n, edges, num_labels):
    def matchings(vertices):
        if not vertices:
            yield []
            return
        u = min(vertices)
        for i,(a,b,label,w) in enumerate(edges):
            if a == u and b in vertices:
                for rest in matchings(vertices - {a,b}):
                    yield [i] + rest
    raw = defaultdict(lambda: [0,0])
    for m in matchings(set(range(n))):
        vec = [0]*num_labels
        for i in m:
            vec[edges[i][2]] += 1
        word = [v for i in m for v in edges[i][:2]]
        raw[tuple(vec)][0] += sign(word)*prod(edges[i][3] for i in m)
        raw[tuple(vec)][1] += 1
    targets = set(raw)
    if num_labels <= 6:
        targets.update(p for p in product(range(3),repeat=num_labels) if sum(p) == n//2)
    for p in targets:
        inside = p in raw
        if not inside:
            options = [v for v in raw if all(a == b or a == 1 for a,b in zip(p,v))]
            inside = any(barycentric(sub,p) for k in range(2,min(len(options),len(p)+1)+1)
                         for sub in combinations(options,k))
        computed = graph_coefficient(n,edges,p)
        assert computed == (inside, *raw.get(p,[0,0])), (edges,p,computed,inside,raw)
        counts["lattice_targets"] += 1
        counts["raw_lattice_holes"] += int(inside and p not in raw)
    counts["graphs"] += 1

for n in [4,6,8]:
    for _ in range(240):
        cells = list(combinations(range(n),2))
        cells = rng.sample(cells,rng.randint(n//2,min(n+2,len(cells))))
        edges, label = [],0
        while cells:
            edges.append((*cells.pop(),label,rng.choice([-2,-1,1,2])))
            if cells and rng.random() < .85:
                edges.append((*cells.pop(),label,rng.choice([-2,-1,1,2])))
            label += 1
        analyze(n,edges,label)

# In k cyclic blocks with determinant a_i(x_i +/- x_{i+1}), the center of
# the (k-1)-dimensional face has precisely two matchings, the two uniform choices.
for k in range(3,15):
    for negate in (False,True):
        edges = []
        for i in range(k):
            u = 4*i
            edges.extend([(u,u+2,i,1),(u,u+3,(i+1)%k,(-1 if negate and i==0 else 1)),
                          (u+1,u+2,k+i,1),(u+1,u+3,k+i,1)])
        # In local vertex order Pfaffian sign is minus det for each block.
        expected = (-1)**k + (-1 if negate else 1)
        assert graph_coefficient(4*k, edges, [1]*(2*k)) == (True, expected, 2)
        counts["high_dimensional_centers"] += 1

print(json.dumps({"status":"all assertions passed","seed":112526,"counts":dict(counts)},indent=2))
