"""Exact signed top-degree coefficient of a product of coordinate exterior binomials.
An option is (tuple of ground elements in wedge order, integer weight).
The determinant wrapper uses matrices of None or (label, integer weight).
"""
from collections import defaultdict
from math import prod


def orientation(word):
    inversions = sum(x > y for i, x in enumerate(word) for y in word[i + 1:])
    return -1 if inversions % 2 else 1


def solve_binary(equations, width):
    """Return offset and systematic kernel basis, encoded as integer bitsets."""
    pivots = {}
    for row, rhs in equations:
        while row:
            pivot = (row & -row).bit_length() - 1
            if pivot not in pivots:
                pivots[pivot] = (row, rhs)
                break
            old, value = pivots[pivot]
            row ^= old
            rhs ^= value
        else:
            if rhs:
                return None

    def back_substitute(initial, homogeneous):
        bits = initial
        for pivot in sorted(pivots, reverse=True):
            row, rhs = pivots[pivot]
            value = ((bits & row).bit_count() % 2) ^ (0 if homogeneous else rhs)
            if value:
                bits |= 1 << pivot
        return bits

    return (back_substitute(0, False),
            [back_substitute(1 << i, True) for i in range(width) if i not in pivots])


def wedge_coefficient(size, slots):
    """Return (signed coefficient, number of contributing selections)."""
    if any(not opts for opts in slots):
        return 0, 0
    for opts in slots:
        if len(opts) > 2 or len({len(seq) for seq, _ in opts}) != 1:
            raise ValueError("expected one or two options of a common grade per slot")
        if any(len(set(seq)) != len(seq) or any(e < 0 or e >= size for e in seq)
               for seq, _ in opts):
            raise ValueError("invalid coordinate blade")
    if sum(len(opts[0][0]) for opts in slots) != size:
        return 0, 0
    rows, rhs = [0] * size, [1] * size
    varying = []
    for i, opts in enumerate(slots):
        for e in opts[0][0]:
            rhs[e] ^= 1
        if len(opts) == 2:
            j = len(varying)
            varying.append(i)
            for e in set(opts[0][0]) ^ set(opts[1][0]):
                rows[e] ^= 1 << j
    solution = solve_binary(zip(rows, rhs), len(varying))
    if solution is None:
        return 0, 0
    offset, kernel = solution
    indices = [0] * len(slots)
    for j, i in enumerate(varying):
        indices[i] = (offset >> j) & 1

    def sign(choices):
        word = [e for i, opts in enumerate(slots) for e in opts[choices[i]][0]]
        return orientation(word)

    base_sign = sign(indices)
    used = set()
    answer = base_sign
    for vector in kernel:
        block = [i for j, i in enumerate(varying) if vector >> j & 1]
        assert used.isdisjoint(block), "the systematic kernel basis must have disjoint supports"
        used.update(block)
        alternate = indices.copy()
        for i in block:
            alternate[i] ^= 1
        first = prod(slots[i][indices[i]][1] for i in block)
        second = prod(slots[i][alternate[i]][1] for i in block)
        answer *= first + base_sign * sign(alternate) * second
    answer *= prod(opts[indices[i]][1] for i, opts in enumerate(slots) if i not in used)
    return answer, 1 << len(kernel)


def determinant_coefficient(matrix, target):
    n = len(matrix)
    if any(len(row) != n for row in matrix):
        raise ValueError("expected a square matrix")
    positions = defaultdict(list)
    for r, row in enumerate(matrix):
        for c, entry in enumerate(row):
            if entry is not None:
                label, weight = entry
                positions[label].append(((r, n + c), weight))
    if any(len(opts) > 2 for opts in positions.values()):
        raise ValueError("occurrence bound exceeded")
    if sum(target.values()) != n:
        return 0, 0
    slots = []
    for label, count in target.items():
        opts = positions[label]
        if count < 0 or count > len(opts):
            return 0, 0
        if count == 1:
            slots.append(opts)
        elif count == 2:
            slots.extend([[opts[0]], [opts[1]]])
    coefficient, multiplicity = wedge_coefficient(2 * n, slots)
    shuffle = (-1) ** (n * (n - 1) // 2)
    return shuffle * coefficient, multiplicity
