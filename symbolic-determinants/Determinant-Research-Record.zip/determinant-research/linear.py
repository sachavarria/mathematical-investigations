"""Linear-size graph algorithm over the integers. Input edge endpoints are ordered.
Returns (raw lattice-point membership, coefficient of the Pfaffian, matching count).
Labels and ground vertices use integer indices. Arithmetic counted at unit cost.
"""
from collections import deque
from math import prod


def permutation_sign(p):
    marked = bytearray(len(p))
    cycles = 0
    for v in range(len(p)):
        if not marked[v]:
            cycles += 1
            while not marked[v]:
                marked[v] = 1
                v = p[v]
    return (-1) ** (len(p) - cycles)


def graph_coefficient(nvertices, edges, target):
    if nvertices % 2 or any(v < 0 for v in target) or sum(target) != nvertices // 2:
        return False, 0, 0
    by_vertex = [[] for _ in range(nvertices)]
    by_label = [[] for _ in target]
    for i, (u, v, label, weight) in enumerate(edges):
        if not (0 <= u < v < nvertices and 0 <= label < len(target) and weight):
            raise ValueError("invalid edge")
        by_vertex[u].append(i)
        by_vertex[v].append(i)
        by_label[label].append(i)
    if any(len(es) > 2 for es in by_label):
        raise ValueError("a label occurs more than twice")
    constraints = by_vertex + by_label
    incident = [(u,v,nvertices+j) for u,v,j,w in edges]
    quotas = [1] * nvertices + list(target)
    remaining = [len(es) for es in constraints]
    active = bytearray([1]) * len(edges)
    queue = deque(range(len(constraints)))
    fixed = []

    def decide(i, take):
        active[i] = 0
        if take:
            fixed.append(i)
        for j in incident[i]:
            remaining[j] -= 1
            quotas[j] -= take
            if remaining[j] <= 2 or quotas[j] == 0:
                queue.append(j)

    # A high-degree vertex needs at most one full scan that decides any edges.
    while queue:
        j = queue.popleft()
        k, q = remaining[j], quotas[j]
        if q < 0 or q > k:
            return False, 0, 0
        if k and q in (0, k):
            for i in constraints[j]:
                if active[i]:
                    decide(i, int(q == k))
    assert all(k == 0 or (k == 2 and q == 1) for k, q in zip(remaining, quotas))
    pairs = []
    for j, es in enumerate(constraints):
        if remaining[j]:
            a, b = [i for i in es if active[i]]
            pairs.append((j, a, b))

    def two_color(include_labels):
        neighbors = [[] for _ in edges]
        for j, a, b in pairs:
            if include_labels or j < nvertices:
                neighbors[a].append(b)
                neighbors[b].append(a)
        color = [-1] * len(edges)
        components = []
        for i in range(len(edges)):
            if not active[i] or color[i] >= 0:
                continue
            sides = [[], []]
            color[i] = 0
            todo = [i]
            while todo:
                v = todo.pop()
                sides[color[v]].append(v)
                for w in neighbors[v]:
                    if color[w] < 0:
                        color[w] = 1 - color[v]
                        todo.append(w)
                    elif color[w] == color[v]:
                        return None
            components.append(sides)
        return components

    if two_color(False) is None:
        return False, 0, 0  # odd residual graph cycle
    components = two_color(True)
    if components is None:
        return True, 0, 0   # raw face exists, requested profile is a hole

    def word(ids):
        return [v for i in ids for v in edges[i][:2]]
    def weight(ids):
        return prod(edges[i][3] for i in ids)
    baseline = fixed + [i for s, t in components for i in s]
    result = permutation_sign(word(baseline)) * weight(fixed)
    for s, t in components:
        pos = {v:i for i,v in enumerate(word(s))}
        relative = permutation_sign([pos[v] for v in word(t)])
        result *= weight(s) + relative * weight(t)
    return True, result, 1 << len(components)
