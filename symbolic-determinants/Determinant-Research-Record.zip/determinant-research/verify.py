"""Deterministic, reproducible verification. Python standard library only."""
import json
import platform
import random
from collections import Counter, defaultdict
from itertools import combinations, permutations, product
from math import prod
from fiber import determinant_coefficient, wedge_coefficient
from reduction import and_clauses, encode

rng = random.Random(20261125)
stats = Counter()


def sign(p):
    # Cycle count, independent of inversion counting in fiber.py.
    visited = set()
    cycles = 0
    for v in range(len(p)):
        if v not in visited:
            cycles += 1
            while v not in visited:
                visited.add(v)
                v = p[v]
    return (-1) ** (len(p) - cycles)


def direct(matrix):
    terms = defaultdict(lambda: [0, 0])
    for p in permutations(range(len(matrix))):
        selected = [row[i] for row, i in zip(matrix, p)]
        if None in selected:
            continue
        key = tuple(sorted(label for label, _ in selected))
        terms[key][0] += sign(p) * prod(weight for _, weight in selected)
        terms[key][1] += 1
    return terms


def partitions(cells):
    if not cells:
        yield ()
        return
    first, *rest = cells
    for groups in partitions(rest):
        yield ((first,),) + groups
    for i, cell in enumerate(rest):
        for groups in partitions(rest[:i] + rest[i + 1:]):
            yield ((first, cell),) + groups


def matrix_test(n, groups, weights, family, all_targets=False):
    matrix = [[None] * n for _ in range(n)]
    for label, group in enumerate(groups):
        for cell in group:
            matrix[cell // n][cell % n] = (label, weights[cell])
    terms = direct(matrix)
    targets = set(terms)
    if all_targets:
        targets.update(tuple(sorted(key)) for key in combinations(
            [i for i, group in enumerate(groups) for _ in group], n))
    else:
        occurrences = [i for i, group in enumerate(groups) for _ in group]
        if len(occurrences) >= n:
            targets.add(tuple(sorted(rng.sample(occurrences, n))))
    stats[family + "_matrices"] += 1
    for key in sorted(targets):
        answer = determinant_coefficient(matrix, Counter(key))
        assert answer == tuple(terms.get(key, (0, 0))), (matrix, key, answer, terms.get(key))
        stats[family + "_targets"] += 1
        if answer[1] and not answer[0]:
            stats["realized_canceled_targets"] += 1
        if answer[1] >= 4:
            stats["targets_with_at_least_four_selections"] += 1


def exact_matrices():
    for mask in range(16):
        cells = [i for i in range(4) if mask >> i & 1]
        for groups in partitions(cells):
            for signs in product([-1, 1], repeat=len(cells)):
                matrix_test(2, groups, dict(zip(cells, signs)), "exhaustive_2", True)
    # All zero patterns and all unlabelled read-two/singleton partitions, positive entries.
    for mask in range(512):
        cells = [i for i in range(9) if mask >> i & 1]
        for groups in partitions(cells):
            matrix_test(3, groups, [1] * 9, "exhaustive_3")
    for n in range(3, 8):
        for _ in range(90):
            cells = rng.sample(range(n * n), rng.randint(n, n * n))
            groups = []
            while cells:
                group = [cells.pop()]
                if cells and rng.random() < 0.88:
                    group.append(cells.pop())
                groups.append(group)
            weights = [rng.choice([-4, -2, -1, 1, 2, 3]) for i in range(n * n)]
            matrix_test(n, groups, weights, "weighted_random")
    # Products with many independent flips, cancellation and unequal weights.
    for blocks in range(1, 19):
        matrix = [[None] * (2 * blocks) for _ in range(2 * blocks)]
        expected = 1
        for j in range(blocks):
            a, b, c, d = [rng.choice([-3, -1, 1, 2]) for _ in range(4)]
            for i, row in enumerate([[a, b], [c, d]]):
                for k, value in enumerate(row):
                    matrix[2*j+i][2*j+k] = (2*j+i, value)
            expected *= a*d - b*c
        answer = determinant_coefficient(matrix, {i: 1 for i in range(2*blocks)})
        assert answer == (expected, 2 ** blocks)
        stats["large_factorized_tests"] += 1


def wedge_tests():
    for _ in range(1600):
        count = rng.randint(1, 8)
        grades = [rng.randint(1, 4) for _ in range(count)]
        n = sum(grades)
        baseline = list(range(n))
        rng.shuffle(baseline)
        slots = []
        for grade in grades:
            blade, baseline = baseline[:grade], baseline[grade:]
            first = blade if rng.random() < 0.88 else rng.sample(range(n), grade)
            other = rng.sample(range(n), grade)
            if rng.random() < 0.32:
                other = list(reversed(first))
            slots.append([(first, rng.choice([-2, -1, 1, 3])), (other, rng.choice([-2, -1, 1, 3]))])
        value = multiplicity = 0
        for options in product(*slots):
            word = [v for seq, w in options for v in seq]
            if len(set(word)) == n:
                multiplicity += 1
                value += sign(word) * prod(w for seq, w in options)
        assert wedge_coefficient(n, slots) == (value, multiplicity)
        stats["exterior_tests"] += 1


def actual_block_coefficient(blocks, target):
    # Enumerate every row permutation locally, then multiply polynomials, truncating
    # at the requested exponents. No assumptions about the number/sign of matchings.
    labels = list(target)
    lookup = {v: i for i, v in enumerate(labels)}
    bounds = tuple(target[v] for v in labels)
    partial = {(0,) * len(labels): 1}
    occurrences = Counter()
    for block in blocks:
        occurrences.update(v for row in block for v in row if v is not None)
        terms = Counter()
        for p in permutations(range(len(block))):
            entries = [r[i] for r, i in zip(block, p)]
            if None not in entries:
                monomial = tuple(sorted(lookup[v] for v in entries))
                terms[monomial] += sign(p)
        nxt = Counter()
        for key, val in partial.items():
            for monomial, factor in terms.items():
                exps = list(key)
                for i in monomial:
                    exps[i] += 1
                if all(exps[i] <= bounds[i] for i in monomial):
                    nxt[tuple(exps)] += val * factor
        partial = nxt
    assert max(occurrences.values()) <= 3
    return partial.get(bounds, 0)


def reduction_tests():
    for a, b in product([0, 1], repeat=2):
        clauses = and_clauses(('a', True), ('b', True), 'c', 'gate')
        models = []
        for c, s, t, u in product([0, 1], repeat=4):
            env = {'a': a, 'b': b, 'c': c, ('gate', 's'): s, ('gate', 't'): t, ('gate', 'u'): u}
            if all(sum(env[k] == pos for k, pos in clause) == 1 for clause in clauses):
                models.append(c)
        assert models == [a & b]
        stats["AND_truth_table_rows"] += 1
    for count in range(1, 6):
        for _ in range(55):
            clauses = [[(rng.randrange(5), rng.choice([False, True])) for _ in range(3)]
                       for _ in range(count)]
            names = sorted({v for clause in clauses for v, _ in clause})
            selector = rng.choice(names)
            signed = unsigned = 0
            for values in product([False, True], repeat=len(names)):
                env = dict(zip(names, values))
                if all(sum(env[v] == pos for v, pos in clause) == 1 for clause in clauses):
                    unsigned += 1
                    signed += (-1) ** int(env[selector])
            for select, expected in [(None, unsigned), (selector, signed)]:
                blocks, target = encode(clauses, select)
                assert actual_block_coefficient(blocks, target) == expected
                stats["reduction_targets"] += 1
                if expected < 0:
                    stats["negative_reduction_targets"] += 1


if __name__ == '__main__':
    exact_matrices()
    wedge_tests()
    reduction_tests()
    print(json.dumps({"status": "all assertions passed", "seed": 20261125,
                      "python": platform.python_version(), "counts": dict(sorted(stats.items()))}, indent=2))
