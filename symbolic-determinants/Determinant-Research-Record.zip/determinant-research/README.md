# Cancellation in determinants with two occurrences per variable

Research record for S.A. Chavarría's Frontier Research Experiment, November 25, 2026, America/New_York. The assignment was to pursue a consequential mathematical discovery in complexity, cryptography or adjacent fields under a finite session budget, with literature checks, counterexamples, proofs and reproducible computation. Codex, a GPT-6-based assistant, derived the results and wrote the programs in one session. A finer model identifier was not independently available. The computation used a CPU, Python 3.12.14 and standard-library integer and rational arithmetic. The manuscript was typeset in LaTeX.

**Candidate original mathematical contribution pending independent verification and confirmation of publication priority.**

## Read the result

Start with the PDF. Pages 2–3 prove the face theorem and generic-rank characterization. Page 4 gives the exterior-algebra lemma. Page 5 identifies the smallest face at an arbitrary lattice point, gives the multiplicity formula and describes the linear-work algorithm. Page 6 proves the counting threshold. Page 7 gives the global algorithmic obstructions. Pages 8–9 record the choice of problem, literature and verification.

In the model each nonzero cell contains one weighted variable and each variable occupies at most two cells. Group perfect matchings by their counts of each variable. Around any integral point of the convex hull of these counts, the smallest face comes from independent even-cycle choices; the integral point is the center of that face. The polynomial on the face factors into binomials. This implies that cancellation preserves the origin of every surviving Newton vertex and gives a matching description of generic rank. Finding the optimal admissible matching in general remains unresolved in this investigation.

## Reproduce

Run these commands from this directory, with Python assertions enabled. They print JSON and leave the supplied execution results intact.

~~~sh
python3 verify.py
python3 geometry.py
python3 nonbipartite.py
python3 lattice.py
python3 obstructions.py
~~~

The corresponding records are results.json, geometry-results.json, nonbipartite-results.json, lattice-results.json and obstruction-results.json. The scripts have no network or package dependencies. Seeds are fixed. For the general exterior algorithm see fiber.py. For linear-work graph coefficient extraction, raw lattice membership and the number of realizing matchings see linear.py. cycles.py takes a perfect matching and returns a surviving exposed matching or an explicit cancelling cycle. reduction.py builds the read-three blocks. paper.tex is the editable manuscript. AUDIT.md records proof challenges and limitations.

To compile the manuscript in a standard TeX Live installation with Latin Modern fonts, run pdflatex twice on paper.tex. The checked PDF is also included.

## A small calculation

For a graph with four ordered vertices, let the rows be 0 and 1 and the columns 2 and 3. Two rows with repeated symbols give a determinant matrix [[a,a],[b,-b]]. The bipartite Pfaffian on the ordered four vertices equals the negative of that determinant.

~~~python
from linear import graph_coefficient
edges = [(0, 2, 0, 1), (0, 3, 0, 1), (1, 2, 1, 1), (1, 3, 1, -1)]
assert graph_coefficient(4, edges, [1, 1]) == (True, 2, 2)
~~~

The three outputs are membership in the raw polytope, the signed Pfaffian coefficient, and the number of contributing matchings. For the determinant wrapper with arbitrary hashable labels, fiber.determinant_coefficient returns the determinant coefficient with the bipartite sign correction already applied.
