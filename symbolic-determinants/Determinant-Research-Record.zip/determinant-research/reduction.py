"""Positive-entry determinant encoding exact-one clauses, with optional signed selector.
Literals are (name, positive); repeated literals are allowed. Variables occur in input.
The output is block diagonal. We keep its blocks separately.
"""
from collections import Counter, defaultdict


def encode(clauses, selector=None):
    occurrences = defaultdict(list)
    target = Counter()
    for j, clause in enumerate(clauses):
        if len(clause) != 3:
            raise ValueError("exactly three literal occurrences per clause required")
        target["T", j], target["F", j] = 1, 2
        for name, positive in clause:
            occurrences[name].append((j, positive))
    if selector is not None and selector not in occurrences:
        raise ValueError("selector must occur")
    blocks = []
    for name, uses in occurrences.items():
        for i, (j, positive) in enumerate(uses):
            # A diagonal matching means false; a cyclic shift means true.
            false_label, true_label = (("F", j), ("T", j)) if positive else (("T", j), ("F", j))
            link = ("link", name, i)
            previous = ("link", name, (i - 1) % len(uses))
            target[link] = 1
            choices = [(false_label, true_label), (previous, link)]
            if name != selector or i != 0:
                pad = ("pad", name, i)
                target[pad] = 1
                choices.append((pad, pad))
            k = len(choices)
            block = [[None] * k for _ in range(k)]
            for r, (diagonal, shifted) in enumerate(choices):
                block[r][r] = diagonal
                block[r][(r + 1) % k] = shifted
            blocks.append(block)
    return blocks, target


def and_clauses(a, b, c, prefix):
    """Inputs are literals. Output is positive variable c. Auxiliaries are fresh."""
    s, t, u = [(prefix, label) for label in 'stu']
    def neg(lit):
        return lit[0], not lit[1]
    return [[(c, True), (s, True), neg(a)], [(c, True), (t, True), neg(b)],
            [(s, True), (t, True), (u, True)]]
