"""Independent exact checks of the face and alternating-cycle criteria."""
from collections import Counter, defaultdict
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, permutations, product
import json
from verify import partitions, sign


def barycentric(points, target):
    """Unique solution on an affinely independent simplex, if strictly positive."""
    k = len(points)
    rows = [[Fraction(x) for x in line] for line in
            [([1] * k + [1])] + [[p[i] for p in points] + [v] for i, v in enumerate(target)]]
    for col in range(k):
        pivot = next((i for i in range(col, len(rows)) if rows[i][col]), None)
        if pivot is None:
            return False
        rows[col], rows[pivot] = rows[pivot], rows[col]
        a = rows[col][col]
        rows[col] = [x / a for x in rows[col]]
        for i in range(len(rows)):
            if i != col and rows[i][col]:
                a = rows[i][col]
                rows[i] = [x - a * y for x, y in zip(rows[i], rows[col])]
    return all(not r[-1] for r in rows[k:]) and all(rows[i][-1] > 0 for i in range(k))


@lru_cache(maxsize=8000)
def face_vertices(points):
    """For each point find raw vertices in its minimal face by exact simplex enumeration."""
    contributors = []
    for i, target in enumerate(points):
        possible = [j for j, other in enumerate(points) if j != i and all(
            not ((v == min(p[k] for p in points) or v == max(p[k] for p in points)) and other[k] != v)
            for k, v in enumerate(target))]
        members = {i}
        for count in range(2, min(len(target) + 1, len(possible)) + 1):
            for subset in combinations(possible, count):
                if barycentric([points[j] for j in subset], target):
                    members.update(subset)
        contributors.append(members)
    vertices = {i for i, s in enumerate(contributors) if len(s) == 1}
    return [members & vertices for members in contributors]


def one_cycle(p, q):
    inv = {c: r for r, c in enumerate(p)}
    moved = [r for r, c in enumerate(q) if c != p[r]]
    if not moved:
        return False
    seen, r = set(), moved[0]
    while r not in seen:
        seen.add(r)
        r = inv[q[r]]
    return len(seen) == len(moved)


def check(grouping, n, masks, stats):
    entries = {cell: label for label, cells in enumerate(grouping) for cell in cells}
    terms = defaultdict(list)
    for p in permutations(range(n)):
        cells = [r*n+c for r,c in enumerate(p)]
        if all(cell in entries for cell in cells):
            counts = Counter(entries[c] for c in cells)
            profile = tuple(counts[j] for j in range(len(grouping)))
            terms[profile].append((p, sign(p), sum(1 << c for c in cells)))
    points = tuple(sorted(terms))
    faces = face_vertices(points)
    for mask in masks:
        survival = set()
        good = False
        for i, profile in enumerate(points):
            fiber = [(p, s * (-1)**((m & mask).bit_count())) for p, s, m in terms[profile]]
            if sum(s for _, s in fiber):
                survival.add(i)
            good |= any(all(t != -s or not one_cycle(p, q) for q,t in fiber) for p,s in fiber)
        assert bool(survival) == good
        for i in survival:
            assert faces[i] <= survival
        stats["signed_matrices"] += 1
        stats["nonzero_determinants"] += bool(survival)
        stats["surviving_nonvertex_profiles"] += sum(len(faces[i]) > 1 for i in survival)
        stats["raw_vertex_deletions"] += sum(faces[i] == {i} and i not in survival for i in range(len(points)))


def run():
    counts = Counter()
    for mask in range(512):
        cells = [i for i in range(9) if mask >> i & 1]
        interior = [i for i in cells if i // 3 and i % 3]
        signs = [sum(1 << i for i, s in zip(interior, bits) if s) for bits in product([0, 1], repeat=len(interior))]
        for grouping in partitions(cells):
            check(grouping, 3, signs, counts)
    # A true interior survivor, and a group of flips supported on two disjoint cycles.
    # Two blocks [x,y;a,a] and [x,y;b,b]. Their determinant is ab(x-y)^2.
    check(((0,10),(1,11),(4,5),(14,15)), 4, [0, 1 << 11], counts)
    # Read-three counterexample, checked by direct expansion.
    from verify import direct
    matrix = [[(s, 1) if s else None for s in row] for row in [('x','x','y'),('z','z','z'),('y',None,'x')]]
    assert dict(direct(matrix)) == {('x','x','z'):[0,2],('x','y','z'):[1,1],('y','y','z'):[-1,1]}
    print(json.dumps({"status":"all assertions passed","counts":dict(counts),
                      "read_three_counterexample":"xyz-y^2z; raw profiles x^2z, xyz, y^2z"},indent=2))


if __name__ == "__main__":
    run()
