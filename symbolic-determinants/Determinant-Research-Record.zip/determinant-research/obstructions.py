"""Exact K5 obstruction and signed-incidence nullity checks."""
from collections import Counter
from fractions import Fraction
from itertools import combinations, combinations_with_replacement, permutations, product
import json
from verify import direct


def rank(matrix):
    if not matrix:
        return 0
    a = [list(map(Fraction,r)) for r in matrix]
    i = 0
    for j in range(len(a[0])):
        pivot = next((k for k in range(i,len(a)) if a[k][j]),None)
        if pivot is None:
            continue
        a[i],a[pivot] = a[pivot],a[i]
        for k in range(i+1,len(a)):
            scale = a[k][j] / a[i][j]
            a[k] = [x-scale*y for x,y in zip(a[k],a[i])]
        i += 1
    return i


def value_checks():
    total = holes = 0
    for h in range(1,5):
        rows = set()
        for j,k in combinations_with_replacement(range(h),2):
            for b in [-1,1]:
                row = [0]*h
                row[j] += 1
                row[k] += b
                rows.add(tuple(row))
        for d in range(5):
            for D in combinations_with_replacement(sorted(rows),d):
                count = sum(all(sum(x*y for x,y in zip(r,s))==0 for r in D)
                            for s in product([-1,1],repeat=h))
                assert count == 0 or count == 2**(h-rank(D))
                total += 1
                holes += count == 0
    return total,holes


def tutte_check():
    n=5
    matrix=[[None if i==j else (tuple(sorted((i,j))),1 if i<j else -1)
             for j in range(n)] for i in range(n)]
    polynomial=direct(matrix)
    assert polynomial and all(value==0 for value, multiplicity in polynomial.values())
    totals=Counter()
    cycles=0
    for tail in permutations(range(1,n)):
        tour=(0,)+tail
        totals.update(tuple(sorted((tour[i],tour[(i+1)%n]))) for i in range(n))
        cycles+=1
    assert all(Fraction(v,cycles)==Fraction(1,2) for v in totals.values())
    assert all(Fraction(k,2)<=k-1 for k in [3,5])
    for s,t in product([1,-1],repeat=2):
        labels=[[('x',1),('x',1),None],[('a',1),('a',s),('b',1)],
                [('c',1),('c',t),('d',1)]]
        output=direct(labels)
        assert output[('a','d','x')][0]==s-1 and output[('b','c','x')][0]==1-t
    return cycles,len(polynomial)


if __name__=='__main__':
    total,holes=value_checks()
    cycles,profiles=tutte_check()
    print(json.dumps(dict(status='all assertions passed',signed_incidence_systems=total,
                          infeasible_sign_systems=holes,K5_Hamilton_tours=cycles,
                          K5_distinct_raw_profiles=profiles,selector_sign_patterns=4),indent=2))
