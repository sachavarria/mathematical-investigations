"""Exact Pfaffian checks using enumerated perfect matchings of undirected graphs."""
from collections import Counter, defaultdict
from itertools import combinations
from math import prod
import json
import random
from cycles import expose
from geometry import face_vertices
from verify import sign

rng = random.Random(77126)
counts = Counter()


def all_matchings(vertices, edges):
    if not vertices:
        yield []
        return
    first, *rest = vertices
    for i, v in enumerate(rest):
        edge = first, v
        if edge in edges:
            for tail in all_matchings(rest[:i] + rest[i + 1:], edges):
                yield [edge] + tail


def trial(n, edges):
    matchings = list(all_matchings(list(range(n)), edges))
    terms = defaultdict(int)
    seq = sorted({label for label, w in edges.values()})
    def profile(m):
        c = Counter(edges[e][0] for e in m)
        return tuple(c[j] for j in seq)
    for m in matchings:
        word = [v for e in m for v in e]
        terms[profile(m)] += sign(word) * prod(edges[e][1] for e in m)
    points = tuple(sorted(terms))
    faces = face_vertices(points)
    surviving = {i for i, p in enumerate(points) if terms[p]}
    assert all(faces[i] <= surviving for i in surviving)
    found = False
    for m in matchings:
        witness, cycle = expose(edges, m)
        if witness is not None:
            j = points.index(profile(witness))
            assert j in surviving and faces[j] == {j}
            found = True
            counts["verified_exposed_witnesses"] += 1
        else:
            left, right = cycle[::2], cycle[1::2]
            assert all(e in m for e in left) or all(e in m for e in right)
            assert profile(left) == profile(right)
            # Renumber vertices in their common induced order and independently check signs.
            vs = sorted(v for e in left for v in e)
            def local_weight(part):
                return sign([vs.index(v) for e in part for v in e]) * prod(edges[e][1] for e in part)
            assert local_weight(left) + local_weight(right) == 0
            counts["verified_cancelling_cycles"] += 1
    assert found == bool(surviving)
    counts["graphs"] += 1
    counts["surviving_nonvertex_profiles"] += sum(len(faces[i]) > 1 for i in surviving)


for n in (4,6,8):
    for _ in range(450):
        possible = list(combinations(range(n),2))
        selected = rng.sample(possible, rng.randint(n//2, min(len(possible), n+5)))
        edges = {}
        label = 0
        while selected:
            edges[selected.pop()] = label, rng.choice([-1,1,1,2])
            if selected and rng.random() < 0.93:
                edges[selected.pop()] = label, rng.choice([-1,1,1,2])
            label += 1
        trial(n, edges)
# Product of two even cycles with identical projected directions, and a selectable
# third 3x3 block that kills one boundary choice. Both phenomena coexist in one graph.
for s, t in [(1,1),(-1,1),(1,-1),(-1,-1)]:
    edges = {(0,2):(0,1),(0,3):(1,1),(1,2):(2,1),(1,3):(2,1),
             (4,6):(0,1),(4,7):(1,s),(5,6):(3,1),(5,7):(3,1),
             (8,11):(4,1),(8,12):(4,1),(9,11):(5,1),(9,12):(5,t),(9,13):(6,1),
             (10,11):(7,1),(10,12):(7,-1),(10,13):(8,1)}
    trial(14, edges)
print(json.dumps({"status":"all assertions passed","seed":77126,"counts":dict(counts)},indent=2))
