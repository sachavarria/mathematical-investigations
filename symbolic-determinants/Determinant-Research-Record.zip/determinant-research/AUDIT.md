# Proof audit

This is an internal adversarial check, written during the derivation. It carries no independent referee endorsement.

| Vulnerable inference | Check or correction |
| --- | --- |
| An odd coverage count need only equal one modulo two. | The sum of all cover counts equals the number of ground elements. If every count is odd, each is at least one, and their fixed sum forces equality everywhere. |
| An affine set of choices could carry a nonlinear determinant sign. | Unit marginals of the one-hot cover force each element to have either one fixed occurrence or exactly two complementary half-probability occurrences. These pairwise relations suffice for feasibility. The resulting free components act on disjoint positions and disjoint element sets. This gives the product formula even with unequal weights. |
| A zero coefficient might signal the absence of every matching. | The routine reports raw polytope membership, number of matching representatives and signed weight separately. The midpoint of det([[x,y],[y,x]]) has no matching. For the product ab(x-y)(x+y) the center has two representatives of opposite sign. |
| Restricting a profile might accidentally cut through the convex hull. | Delete a label of count zero or require all its remaining occurrences. These are exposed coordinate extrema. Forced-vertex deletions are translations by a common monomial. Iterate with the residual quotas. |
| Products on different cycles may share variables. | Exposing a vertex maximizes each factor's weight. Every extremal factor coefficient survives, and their product is nonzero in a field. Shared variables can still cancel at nonextremal profiles. |
| The terminal face might be larger than the smallest face at the target. | An equal mixture of all cycle choices gives the target, since every remaining label occurs exactly twice. This is a strictly positive average of all projected cube corners. The target is in the relative interior. |
| Rank characterization might inadvertently claim that an admissible matching's own coefficient survives. | A matching without a single cancelling cycle may still participate in coordinated cancellation across cycles. Its profile belongs to a face with surviving vertices. Existence of some surviving profile is enough for generic rank. |
| A forbidden cycle might use edges omitted from a given minor. | If it alternates with a matching, its vertices are all covered by that matching. Its entire alternating cycle is present in the induced row/column minor. Each of its colors uses both occurrences on the cycle. |
| A feasible coefficient fiber of size a power of two might vanish modulo an odd prime with unequal weights. | Odd-characteristic invariance assumes integer weights +1 or -1. Weighted face factorization has no such unit restriction. An integer coefficient of magnitude 3 is possible with nonunit weights. |
| A polynomial identity over a finite field might be confused with evaluation at one assignment. | Generic rank is taken over the rational function field in independent formal indeterminates. The results make no inference about an arbitrary chosen evaluation. |
| Calling the positive-entry read-three problem #P-complete might overlook negative permutation signs. | Every permutation term on the all-three-by-three subclass is positive. For the signed gap a single two-by-two block contributes the selector sign, even though every matrix entry has positive scalar. |
| A count reduction may multiply the number of satisfying assignments. | Every link fixes equality, padding choices are fixed by the block state, and gate auxiliaries extend uniquely. Negated and repeated literals are counted by occurrence. The output unit constraint and unused-witness gadget have unique slack values. |
| Complexity may depend on integer sizes. | Linear work in the graph version counts combinatorial operations and ring operations after indexing labels. The output length, integer multiplication and integer comparisons incur their normal bit costs. |
| Representative test counts might suggest exhaustive large-dimensional coverage. | The all-pattern three-by-three checks exhaust symmetry representatives at that size. There are only two additional four-by-four cases in the geometry sweep. Other graph and target families are sampled or designed. The proofs supply the unrestricted dimension claims. |

## Further questions

1. Can a deterministic algorithm find a maximum matching that avoids cancelling alternating cycles for arbitrary placements of paired symbols? The cycle criterion checks a proposed witness, while the K5 example rules out one fractional relaxation.
2. Is there a useful analogue of the odd-set inequalities that can be separated in polynomial time for these color pairings? The Tutte specialization supplies a necessary test for any proposed answer.
3. Which parts of the paired-coordinate face theorem follow from existing results on matching polytope projections or sparse determinant representations? A specialist literature and proof review is required before any assertion of priority.

## Additional literature checked

The cited work on sparse coordinate occurrences should also be distinguished from bounded *individual degree* in arithmetic expressions. The latter admits #P-hard coefficient problems already at individual degree two. [Juma, thesis, Lemma 2.6.4](https://www.cs.toronto.edu/~ajuma/thesis.pdf).

Loebl studies a different parity-matching problem in which specified pairs may have zero or two selected edges. A target profile here specifies every count exactly. [Parity Matching](https://kam.mff.cuni.cz/~loebl/clanky/parityMatching0416.pdf).

The targeted search included colored structured systems and equivalence-class signatures, Sachs expansions, projected Newton polytopes, bounded-read determinant representations, partitioned symbolic matrices, mixed discriminants, matching parity and coefficient complexity. Terminology varies across these literatures.
