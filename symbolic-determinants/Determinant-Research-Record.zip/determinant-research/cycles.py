"""Constructive face restriction for an undirected weighted labelled simple graph.
Edges are endpoint pairs (u,v), u<v. Each value is (label, nonzero integer).
A perfect matching is supplied. The result is a surviving exposed profile or a
cancelling alternating cycle (characteristic zero, Pfaffian convention).
"""
from collections import Counter, defaultdict
from fiber import orientation


def matching_sign(matching):
    return orientation([v for edge in sorted(matching) for v in edge])


def expose(edges, matching):
    from math import prod
    initial = set(matching)
    vertices = {v for e in edges for v in e}
    if not initial <= edges.keys() or len(vertices) != 2 * len(initial) or {v for e in initial for v in e} != vertices:
        raise ValueError("a perfect matching on the incident vertices is required")
    if any(u >= v or w == 0 for (u, v), (_, w) in edges.items()):
        raise ValueError("edges must be ordered, loopless and have nonzero weight")
    if any(k > 2 for k in Counter(x for x,w in edges.values()).values()):
        raise ValueError("occurrence bound exceeded")
    order = list(dict.fromkeys(label for label, w in edges.values()))
    live = dict(edges)
    chosen = initial.copy()
    fixed = set()
    while live:
        selected = Counter(live[e][0] for e in chosen)
        absent = {e for e, (label, _) in live.items() if not selected[label]}
        if absent:
            for e in absent:
                del live[e]
            continue
        forced = {e for e in chosen if selected[live[e][0]] == 2}
        if not forced:
            degree = Counter(v for e in live for v in e)
            forced = {e for e in chosen if any(degree[v] == 1 for v in e)}
        if not forced:
            break
        fixed.update(forced)
        chosen -= forced
        endpoints = {v for e in forced for v in e}
        live = {e: val for e, val in live.items() if not endpoints.intersection(e)}
    neighbors = defaultdict(list)
    for u, v in live:
        neighbors[u].append(v)
        neighbors[v].append(u)
    assert all(len(ns) == 2 for ns in neighbors.values())
    unseen = set(neighbors)
    witness = fixed.copy()
    while unseen:
        first = min(unseen)
        cur, prev = first, None
        cycle = []
        while True:
            unseen.remove(cur)
            nxt = next(v for v in neighbors[cur] if v != prev)
            cycle.append(tuple(sorted((cur, nxt))))
            prev, cur = cur, nxt
            if cur == first:
                break
        left, right = cycle[::2], cycle[1::2]
        def profile(part):
            c = Counter(live[e][0] for e in part)
            return tuple(c[v] for v in order)
        def signed_weight(part):
            return matching_sign(part) * prod(live[e][1] for e in part)
        p, q = profile(left), profile(right)
        if p == q and signed_weight(left) + signed_weight(right) == 0:
            return None, cycle
        witness.update(left if p >= q else right)
    return witness, None
