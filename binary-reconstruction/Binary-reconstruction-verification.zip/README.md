# Replay guide
Read Binary-reconstruction-proof.md for the statement, proof, assumptions and review questions. Research-history.md is the chronological record including prior experiments and code.

Run python3 replay.py with libz3 installed, or z3 obligations.smt2 directly. The expected result is seven unsat and one sat, in order. These are local arithmetic checks. For the independent complete length-20 census, run:
~~~sh
g++ -O2 -std=c++20 census20.cpp -o census20
./census20
~~~
Expected size and class counts: 1 1024; 2 523664; 4 56. Hash collisions cannot merge unequal string keys. All counts in one byte are at most 20. Source for earlier experiments is preserved verbatim in Research-history.md.
