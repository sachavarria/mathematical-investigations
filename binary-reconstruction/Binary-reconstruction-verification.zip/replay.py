"""Run the SMT-LIB file against the native Z3 library. Requires Python 3 and libz3."""
import ctypes as c
from ctypes.util import find_library
from pathlib import Path

lib = c.CDLL(find_library("z3") or "libz3.so.4")
def bind(name, result, *arguments):
    fn = getattr(lib, name)
    fn.argtypes, fn.restype = arguments, result
    return fn

ptr = c.c_void_p
config = bind("Z3_mk_config", ptr)()
context = bind("Z3_mk_context", ptr, ptr)(config)
evaluate = bind("Z3_eval_smtlib2_string", c.c_char_p, ptr, c.c_char_p)
print("Z3", bind("Z3_get_full_version", c.c_char_p)().decode())
answers = evaluate(context, Path(__file__).with_name("obligations.smt2").read_bytes()).decode().split()
print(" ".join(answers))
if answers != ["unsat"] * 7 + ["sat"]:
    raise SystemExit("unexpected solver response")
