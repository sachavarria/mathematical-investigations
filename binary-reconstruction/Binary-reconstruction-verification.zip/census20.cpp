// Exhaustive exact record census, partitioned by total weight.
// Each byte is the number of windows having the given (length,ones) pair.
#include <array>
#include <bit>
#include <cstdint>
#include <iostream>
#include <map>
#include <string>
#include <unordered_map>
int main() {
    constexpr unsigned n=20, limit=1u<<n;
    std::map<unsigned,unsigned> histogram;
    for (unsigned weight=0;weight<=n;++weight) {
        std::unordered_map<std::string,unsigned> classes;
        for (unsigned word=0;word<limit;++word) {
            if (unsigned(std::popcount(word))!=weight) continue;
            std::string record(230,0); // sum(length+1), lengths 1..20
            for (unsigned start=0;start<n;++start) {
                unsigned ones=0;
                for (unsigned length=1;start+length<=n;++length) {
                    ones+=(word>>(start+length-1))&1;
                    const unsigned offset=(length-1)*(length+2)/2;
                    ++record[offset+ones];
                }
            }
            ++classes[record]; // key equality compares every byte
        }
        for (auto const& entry:classes) ++histogram[entry.second];
    }
    unsigned total=0;
    for(auto [size,count]:histogram) {
        std::cout<<size<<" "<<count<<"\n";
        total+=size*count;
    }
    return total==limit ? 0 : 1;
}
