# Binary reconstruction • Mathematical research record
## 18 November 2026 • Entry 1
Question: for a prime p≥5, does the largest record class at length 3p−1 have four or eight members? Reversals count individually. The observation includes multiplicities of every nonempty contiguous substring, with distinguished bit labels and no missing records.

Literature audit: Acharya, Das, Milenkovic, Orlitsky & Pan, SIAM J. Discrete Math. 29 (2015), DOI 10.1137/140962486, author's full text https://people.ece.cornell.edu/acharya/papers/str_rcn_sidma.pdf . Use the factor-choice characterization, diagonal specialization lemma, prime-minus-one reconstruction theorem, and interleaving lower bound. The paper explicitly asks whether the lower bound always holds with equality and reports interleaved confusability through length 22. Later searches covered mixed primes, maximal equicomposability, homometry, and interleaving. Related work on partial records (arXiv:2208.14963), error correction, and graph generalization (arXiv:2504.00169) concerns different questions. No prior proof of this specialization was located. This is provisional priority information.

### Worked witness
Take three identical blocks, either 0001 or 1000, and two separator bits, either 01 or 10 in order. Literal counting verified all four words have the same record. Each walk is a local prefix set translated to each of three anchors. Reversal of the block reflects the local set; swapping the separators reflects the anchor set. Ordered differences are invariant under point reflection because each ordered pair has an opposite ordering. Sums of the local and anchor differences give every ordered difference with multiplicity because every prefix has a unique decomposition.

### Experiments and decisions
First calibrate exhaustive grouping at length 14, then at length 32 enumerate every word of weight ≤4. Separate programs within the script use substring counts and prefix displacements and check a bijection between the resulting record keys. Weight is part of a record, so these are whole classes. Number of classes by size (one,two,four): length 14 (128,8104,12); length 32 weights 0 through 4 respectively (1,0,0), (0,16,0), (16,240,0), (0,2480,0), (120,17910,5). No statistical extrapolation. Complementation covers weights ≥28.
Second experiment: look for factors 1+x+xy by evaluation at (2,−3/2) modulo 1000000007. For halves A,B use P_AB=P_A+m_A(P_B−1), where m_A represents the endpoint. Enumerate both half lists, index by P_B, retain all matches. False positives are allowed. At lengths 14,20,32 there were 16,64,1024 matches before including reversals. Independently generated all words 01 b1 01 ... br 01 and compared sets: exact agreement at all three lengths. With reversals included the size-two/size-four counts inside these filters were (4,6),(8,28),(32,496). Filtering alone cannot rule out classes it omits. The rigidity proof below supplied the missing theoretical connection. We abandoned a plan to enumerate all 2^32 words.

### Proof draft for review
Let P_s=sum over all prefixes of x^(number of zeros)y^(number of ones), including the empty prefix. Reversal replaces P by P*=x^deg_x(P)y^deg_y(P)P(1/x,1/y). The 2015 factor theorem says the entire class is given by independently taking each normalized irreducible factor or its reciprocal, and every such choice is a prefix polynomial. Constant terms are normalized to 1. Nonreciprocal means F differs from F*. A class of eight needs three nonreciprocal irreducibles. Diagonal specialization gives exactly the distinct irreducibles Phi_3 Phi_p Phi_3p. Every nonconstant factor has nonconstant diagonal (Acharya et al., Lemmas 19–20). Thus in an eight-class some factor F has diagonal 1+t+t² and is nonreciprocal.

For clarity on degrees, write P=FQ. The total degree of P equals deg_x P + deg_y P, since the endpoint realizes both maxima. Degrees add under products in this integral domain, and total degree never exceeds that sum. Equality therefore holds for F and Q separately. Each has one top monomial (the only way to attain this sum), so diagonalization preserves its degree. Hence F has total degree two. A univariate F would be 1+x+x² or its y counterpart, both reciprocal. Otherwise the bidegree is (1,1) and F=1+a x+(1−a)y+xy with a integral. Since F(x,0) divides P(x,0)=1+x+...+x^r (r initial zeros), any nonconstant 1+a x has a root of modulus one, forcing |a|=1. Similarly 1−a is 0 or has absolute value one. Together these give a=0 or 1. Thus F is 1+x+xy or its reciprocal. By reversing a word we can fix the first orientation.

Rigidity: set F=1+x+xy and P_s=FQ. By the published factor flip theorem P_h=F*Q is another path polynomial. Thus P_s−P_h=(x−y)Q. On the diagonal Q(t,t)=sum_{k=0}^{p−1} t^(3k). Apply partial derivative in x before setting x=y=t. The coefficient of t^(i−1) on the left is the difference in zero counts in the first i bits of s and h (prefix monomials have total degree i). On the right it is 1 for i=1 mod 3 and 0 otherwise. The difference starts at zero. At positions 3k+1 it increases by one, forcing bits 0 in s and 1 in h. At 3k+2 it decreases by one, forcing bits 1 in s and 0 in h. At multiples of three it stays zero, forcing equal bits. This includes the final two-bit block. Therefore s=01 b1 01 ... b_(p−1) 01.

For such words the quotient Q=P_b(x²y,xy²): each separator 0 moves from one block start to the next by (2,1), each 1 by (1,2). For two F-oriented members, cancel FF* in the product equality P_s P_s*=P_h P_h*. Substitution commutes with reciprocal on these path polynomials since the final prefix simultaneously maximizes both exponents before and after substitution. The substitution is injective because the matrix with columns (2,1),(1,2) has determinant 3, so distinct monomials remain distinct. Therefore the two separator words have identical prefix-polynomial products with their reciprocals, hence identical substring-composition records. They have length p−1, and the published prime-minus-one reconstruction theorem gives at most two separator words. At most two F-oriented members exist. Every member carries either F or F* by the factor-choice characterization. Reversal maps the latter to the former, so the entire class has at most four members. This contradicts eight. The published lower bound supplies four at every target length. Conclusion of this argument: E_(3p−1)=4.

Adversarial checks: the flip theorem is needed for genuine paths even if Q has signed coefficients; diagonal squarefreeness excludes lost or repeated factors; normalization removes unit signs; equal diagonal polynomials alone do not certify an equal record; injectivity after substitution is required; no inference from sparse words to arbitrary weights is used. The draft is a mathematical argument based on published lemmas, examined internally and not formally verified or independently reviewed. No novelty claim. Next review target: independently formalize the factor-rigidity and cancellation steps, and check prior work on interleaving converses. No implication for all mixed primes is asserted.

### Reproducibility • Python 3.8+ • run each listing under its filename
#### census.py
~~~python
from itertools import combinations, product
from collections import Counter, defaultdict

def literal(s):
    n = len(s)
    rows = []
    for length in range(1, n+1):
        counts = [0]*(length+1)
        for start in range(n-length+1):
            counts[s[start:start+length].count("1")] += 1
        rows.extend(counts)
    return bytes(rows)

def displacements(s):
    n = len(s)
    points = [(0,0)]
    for bit in s:
        x,y = points[-1]
        points.append((x+(bit=="0"),y+(bit=="1")))
    # Independent integer encoding, including all ordered displacements.
    # Base larger than every coefficient; stride prevents coordinate aliases.
    base = 1 << (n+1).bit_length()
    powers = [x*(2*n+1)+y for x,y in points]
    top = powers[-1]
    return sum(base**e for e in powers)*sum(base**(top-e) for e in powers),top

def check(words):
    # Verify both directions of the correspondence for all words in this run.
    f,g,counts = {},{},Counter()
    for s in words:
        a,b = literal(s),displacements(s)
        assert f.setdefault(a,b)==b and g.setdefault(b,a)==a
        counts[a]+=1
    return sorted(Counter(counts.values()).items())

if __name__=="__main__":
    print("14",check(map("".join,product("01",repeat=14))),flush=True)
    # At 32, use a separate, compact representation for geometric signatures.
    # Record unsigned coordinate differences via gaps between prefix positions
    # with fixed numbers of ones; count all ordered endpoints in those layers.
    def layers(s):
        groups = defaultdict(list)
        y=0
        groups[0].append(0)
        for i,b in enumerate(s,1):
            y += int(b)
            groups[y].append(i)
        hist=Counter()
        for h,left in groups.items():
            for k,right in groups.items():
                if k>=h:
                    for i in left:
                        for j in right:
                            if j>i: hist[j-i,k-h]+=1
        return bytes(hist[d,w] for w in range(y+1) for d in range(1,len(s)+1))
    for weight in range(5):
        f,g,counts={},{},Counter()
        for marks in combinations(range(32),weight):
            row=list("0"*32)
            for i in marks: row[i]="1"
            s="".join(row)
            a,b=literal(s),layers(s)
            assert f.setdefault(a,b)==b and g.setdefault(b,a)==a
            counts[b]+=1
        print("32",weight,sorted(Counter(counts.values()).items()),flush=True)
~~~
#### filtered.py
~~~python
from collections import defaultdict,Counter
from census import literal

def half(k,mod):
    x=2
    y=(-3*pow(2,-1,mod))%mod
    rows=[("",1,1)]
    for _ in range(k):
        rows=[(s+b,(m*v)%mod,(a+m*v)%mod)
              for s,m,a in rows for b,v in (("0",x),("1",y))]
    return rows

def search(n):
    mod=1000000007
    rows=half(n//2,mod)
    by=defaultdict(list)
    for s,m,a in rows: by[a].append(s)
    words=set()
    for s,m,a in rows:
        target=(1-a*pow(m,-1,mod))%mod
        for t in by.get(target,()):
            w=s+t
            words.update((w,w[::-1]))
    counts=Counter(literal(s) for s in words)
    print(n,len(words), sorted(Counter(counts.values()).items()),flush=True)
if __name__=="__main__":
    for n in (14,20,32):search(n)
~~~

## Entry 2 • 18 November 2026 • Adversarial audit
The published SIAM pagination and numbering are from https://people.csail.mit.edu/jayadev/papers/sidma-strings.pdf . Lemmas 4–5 equate the full multiplicity record of a binary string with prefix autocorrelation. Theorem 12 gives all independent reciprocal choices for the integer irreducible factors of a string generating polynomial, each with positive constant term; they are all string polynomials. Corollary 13's upper bound alone forces ≥3 nonreciprocal factors from eight words. Lemmas 19–20 prohibit diagonal degree loss for these factors. Theorem 22 recovers a binary separator of length p−1 up to reversal when p is prime. Theorem 26 explicitly gives the entire class of an interleaving as interleavings of independently equicomposable component words. It subsumes the separator inheritance once block structure has been proved. I missed that in the first review. Lemma 28 gives the substitution formula; Theorem 27 supplies the four lower bound. The diagonal partial derivative is already used in the published proof of Theorem 24. Priority of the combined 3p−1 argument remains unverified.

Independent quadratic check: exactly three nonreciprocal factors and three distinct diagonal irreducibles force a normalized lift of Phi_3 alone. The degree/bidegree justification is in Entry 1. For a mixed lift H=1+a x+(1−a)y+xy, its reciprocal interchanges the two linear coefficients. By Theorem 12 both HQ and H*Q are paths. Since Q(0,0)=1, the difference of their x coefficients is 2a−1. Each path has coefficient zero or one at x, so |2a−1|≤1, hence a=0 or 1. This argument is independent of the root-of-unity restriction used in Entry 1. A univariate lift is reciprocal. Dropping the path requirement admits the spurious lift 1+2x−y+xy. Dropping saturation admits the all-zero word with the same length diagonal but no mixed quadratic divisor.

Direct inheritance proof: in u b1 u ... bm u, with u fixed to 01 or 10, for each k=1..m take all windows of length 3k. For separator indices j+1..j+k (0≤j≤m−k) there are exactly three starts, indices 3j,3j+1,3j+2 counted from zero. Those windows contain precisely those k separators and k copies of each fixed bit, because the two fixed residue classes modulo three occur k times each. Thus multiplicity of r ones among length-k separator windows equals one third of the multiplicity of k+r ones among full length-3k windows. This explicitly decodes every separator record and permits different orientations between whole words. No differentiation, factor theorem, or cancellation enters this decoding.

Exact finite stress tests below. For every word of length 0 through 14 (32,767 words), compare intended block structure with the exact coefficients after setting y=−(1+x)/x and clearing the denominator by x^n. Vanishing is equivalent to divisibility since 1+x+xy is primitive as a polynomial in y over Z[x] (coefficients x and 1+x are coprime), by Gauss's lemma. Checked both orientations of encodings for every separator word of lengths 0 through 10, testing all nonempty window lengths. Verified eight explicit distinct mutually equicomposable words at length 26 and at length 124 by recursively interleaving three independently oriented copies of 01 or 0001 respectively. At length 26 the middle parameter is composite (9), and at length 124 the diagonal has no Phi_3. These invalidate broader claims, not the target family. No proof-assistant verification or outside review. Status: a deductive proof draft from published results and the separately proved lift and rigidity steps. Computational agreement is corroboration only.
~~~python
from itertools import product
from math import comb
from collections import Counter
def words(n):
    return map(''.join, product('01', repeat=n))
def wrap(u,b):
    return u+''.join(c+u for c in b)
def record(w,k):
    return Counter(w[i:i+k].count('1') for i in range(len(w)-k+1))
def divisible(s):
    n=len(s); a=b=0; terms=Counter()
    for c in ' '+s:
        a+=c=='0'; b+=c=='1'
        for j in range(b+1):
            terms[n+a-b+j]+=(-1)**b*comb(b,j)
    return not any(terms.values())
for n in range(15):
    for s in words(n):
        assert divisible(s)==(n%3==2 and all(s[i:i+2]=='01' for i in range(0,n,3)))
for m in range(11):
    for b in words(m):
        for u in ('01','10'):
            w=wrap(u,b)
            for k in range(1,m+1):
                assert record(w,3*k)=={k+j:3*v for j,v in record(b,k).items()}
for blocks in [('01','01','01'),('0001','0001','0001')]:
    rows={wrap(u,wrap(v,w)) for u in (blocks[0],blocks[0][::-1]) for v in (blocks[1],blocks[1][::-1]) for w in (blocks[2],blocks[2][::-1])}
    assert len(rows)==8
    n=len(next(iter(rows)))
    assert len({tuple(tuple(sorted(record(s,k).items())) for k in range(1,n+1)) for s in rows})==1
    print(n,len(rows))
print('all assertions passed')
~~~

## Entry 3 • Independent verification preparation • 18 November 2026
Prepared Binary-reconstruction-proof.md as a standalone review draft with a dependency register and clear boundaries for the imported results. Correction to the earlier dependency description: the published paper's Corollary 13 is the inequality; Corollary 18 is the exact power-of-two formula. The exact formula or an equivalent squarefreeness argument is needed to eliminate class sizes five through seven.
A derivative-free two-word induction now proves rigidity from P_s G=P_h F for every length 3m+2. Comparing degrees one and two forces the opposite initial blocks; removing them gives a common separator and exactly the original identity on the suffixes. This replaces the derivative step while retaining the published factor-flip hypothesis. The review draft contains the full derivation. We retained both proofs for audit.
A Lean installation was not located. Z3 4.13.3 checked seven arithmetic obligations and a satisfiable weakened control. The formulas cover the bit transitions and boundary indexing but do not encode the entire theorem. A clean C++ literal-record census at length 20 found 1,024 singleton, 523,664 two-word and 56 four-word classes. Total 1,048,576 words. This independently validates that finite maximum and does not settle the general question. Replay files are in Binary-reconstruction-verification.zip. No referral to an external person or system was made; the local solver executed our formulas. The choice between blind model review, specialist review, and extending formalization is reserved for joint decision. Literature search again found the original general open question and did not establish novelty of this specialization.
